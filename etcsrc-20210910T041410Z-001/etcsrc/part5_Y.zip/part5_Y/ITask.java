package part5.part5_Y;

public interface ITask {
    public void setExecNumber(int x);
    public void exec();
    public int getResult();
}
