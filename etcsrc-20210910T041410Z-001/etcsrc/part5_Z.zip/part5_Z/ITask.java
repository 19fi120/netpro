package part5.part5_Z;

public interface ITask {
    public void setExecNumber(int x);
    public void exec();
    public int getResult();
}
