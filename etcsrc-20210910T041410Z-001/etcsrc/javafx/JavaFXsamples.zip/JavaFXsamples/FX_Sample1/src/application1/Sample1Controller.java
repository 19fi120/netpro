package application1;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class Sample1Controller {
	//FXMLで定義したTextFieldをここで取得する（FXMLで定義したidはtext）初期値の設定はいらない
	@FXML TextField text;
	//FXMLで定義したLabelをここで取得する（FXMLで定義したidはlabel）初期値の設定はいらない
	@FXML Label label;

	//ボタンがクリックされたら動作するメソッド（FXMLにonActionで定義する）
	@FXML
	private void buttonAction(){
		//TextFieldの中身をコンソールに表示
		System.out.println("ボタンがクリック:"+text.getText());
		//TextFieldの中身をラベルに表示
		label.setText(text.getText());
	}
}
