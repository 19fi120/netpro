package application1;
	
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;


public class Main extends Application {
	@Override
	public void start(Stage primaryStage) {
		try {
			//ここで作成したfxmlを指定する
			Parent root = FXMLLoader.load(getClass().getResource("Sample1_Screen.fxml"));
			//ウィンドウにタイトルを付ける
			primaryStage.setTitle("Sample1");
			//第2引数と第3引数で、最初のウインドウサイズの横と縦を指定する
			Scene scene = new Scene(root,500,300);
			scene.getStylesheets().add(getClass().getResource("application1.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
