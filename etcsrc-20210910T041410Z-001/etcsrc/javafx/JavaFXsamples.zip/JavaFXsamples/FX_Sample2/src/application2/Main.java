package application2;
	
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;
/*
	Ctrlキーを押しながらウィンドウ内をクリックすると赤、CtrlキーとShiftキーを押しながらクリックすると緑
	Shiftキーを押しながらクリックすると青色で図形が描画される。
	なにも押さずにクリックした場合は黒色で描画される。
 */

public class Main extends Application {
	@Override
	public void start(Stage primaryStage) {
		try {
			Parent root = FXMLLoader.load(getClass().getResource("Sample2_Screen.fxml"));
			primaryStage.setTitle("Sample2");
			Scene scene = new Scene(root,400,400);
			//キーイベントを受け付けるためにアクティブにする（これがないとキーイベントを受けてくれない）
			scene.getRoot().requestFocus();
			scene.getStylesheets().add(getClass().getResource("application2.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
