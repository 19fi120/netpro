package application2;

import javafx.fxml.FXML;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;

public class Sample2Controller {
	
	//BorderPaneはSwingでいうBorderLayoutと同じ、置く場所をそれぞれ中央・上・下・右・左から指定する
	
	@FXML Canvas canvas;
	//キーイベントのCTRLキーとSHIFTキーのフラグ
	private static boolean CTRL = false;
	private static boolean SHIFT = false;
	//四角形を描画する半径
	private static final int RADIAN = 20;
	
	//FXMLを読み込んでfx:idを初期化した後に呼ばれるメソッド（初期化するならこのメソッド内）
	//@FXMLの下にinitialize()を実装する、もう一つ初期化メソッドを実装する方法がある（SampleChatで紹介）
	@FXML
	void initialize(){
		//キャンバスの大きさ（FXML内で定義しても良い）
		canvas.setWidth(400);
		canvas.setHeight(400);
	}
	
	//マウスが押されたときの処理
	@FXML
	public void mousePressedAction(MouseEvent event){
		//SwingでいうGraphics2Dクラス、このクラスで描画をする
		GraphicsContext gc = canvas.getGraphicsContext2D();
		//もしCTRLキーとSHIFTキーがどちらも押されていたなら
		if(CTRL && SHIFT){
			//次の描画を緑で塗る
			gc.setFill(Color.GREEN);
		//もしCTRLキーが押されていたなら
		}else if(CTRL){
			//次の描画を赤で塗る
			gc.setFill(Color.RED);
		//もしSHIFTキーがどちらも押されていたなら
		}else if(SHIFT){
			//次の描画を青で塗る
			gc.setFill(Color.BLUE);
		//もしどちらも押されていないなら
		}else{
			//次の描画を黒で塗る
			gc.setFill(Color.BLACK);
		}
		//マウスが押された座標で、四角形を描画する
		gc.fillRect(event.getX()-RADIAN/2,event.getY()-RADIAN/2,RADIAN,RADIAN);
	}
	
	
	//キーが押されたときの処理
	@FXML
	public void keyPressedAction(KeyEvent event){
		//なんのキーが押されたか
		switch(event.getCode()){
			case CONTROL:
				//CTRLキーのフラグを立てる
				CTRL = true;
				break;
			case SHIFT:
				//SHIFTキーのフラグを立てる
				SHIFT = true;
			default:
		}
	}
	
	//キーが離されたときの処理
	@FXML
	public void keyReleasedAction(KeyEvent event) {
		//なんのキーが離されたか
		switch(event.getCode()){
			case CONTROL:
				//CTRLキーのフラグを解除する
				CTRL = false;
				break;
			case SHIFT:
				//SHIFTキーのフラグを解除する
				SHIFT = false;
			default:
		}
	}
}
