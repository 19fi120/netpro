package application3;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;

public class Sample3Controller {
	//VBoxは縦にコンポーネントを置いていくレイアウト
	@FXML VBox append;
	@FXML TextField text;
	
	//追加ボタンの動作
	@FXML
	public void appendText(){
		//テキストフィールドから入力された文字を取得する
		String message = text.getText();
		//文字が空でなければ
		if(!message.equals("")){
			//BorderPaneを作る
			BorderPane border = new BorderPane();
			//Label（テキストを表示する）を、指定した引数をテキストとして作る
			Label messageLabel = new Label(message);
			//BorderPaneの左側にLabelを置く
			border.setLeft(messageLabel);
			//ボタンを、指定した引数をボタンに表示する文字として作る
			Button delete = new Button("削除");
			//ボタンに押された処理を設定する。（具体的にはhandleメソッドの中）
			delete.setOnAction(new EventHandler<ActionEvent>(){
				@Override
				public void handle(ActionEvent event) {
					//ActionEventから押されたボタンを取り出す　→　event.getSource()
					//押されたボタンが置かれているコンポーネント（ここではBorderPane）を取り出す　→　getParent()
					//消したいコンポーネント（ボタンとテキストが乗っているBorderPane）を指定する
					deleteText(((Button) event.getSource()).getParent());
				}				
			});
			//BorderPaneの左側にボタンを置く
			border.setRight(delete);
			//VBoxにBorderPaneを置く
			append.getChildren().add(border);
			//テキストフィールドの中身を消す
			text.setText("");
		}
	}
	
	public void deleteText(Node node){
		//VBoxから指定されたコンポーネントを削除する
		append.getChildren().remove(node);
	}
}
