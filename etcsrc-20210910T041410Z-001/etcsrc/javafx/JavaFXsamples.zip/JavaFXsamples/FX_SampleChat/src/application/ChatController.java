package application;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;

public class ChatController implements Initializable{
	//VBoxは縦に置くレイアウト
	@FXML VBox message_display;
	@FXML TextField send1;
	@FXML TextField send2;
	//BorderPaneは中央・上・下・右・左を指定するレイアウト
	@FXML BorderPane chat1_border;
	@FXML BorderPane chat2_border;
	//ScrollPaneはスクロールバーが表示される
	@FXML ScrollPane scroll;
	//チャット入力欄の大きさ
	private static final int INPUT_PART_HEIGHT = 100;
	//チャットを出力するときのスペース
	private static final int CHAT_SPACE = 5;
	
	//初期化のもう一つの方法（他の方法はSample2で紹介）
	//コントローラクラスにInitializableインターフェースを継承して、initializeメソッドをオーバライドする
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		//チャット入力部分のコンポーネントの高さを指定
		chat1_border.setPrefHeight(INPUT_PART_HEIGHT);
		chat2_border.setPrefHeight(INPUT_PART_HEIGHT);
	} 
	
	//チャットを送信するボタンの処理
	@FXML
	public void sendAction(ActionEvent e){
		//呼び出されたコントローラ
		Object source = e.getSource();
		//ボタンにキャストできるなら
		if(source instanceof Button){
			//ボタンのIDを取得して引数にする
			sendMessage(((Button) source).getId());
		}
		//スクロールを後方に移動
		scroll.setVvalue(1.);
		
	}
	
	
	private void sendMessage(String sender){
		//BoderPaneを作成
		BorderPane pane = new BorderPane();
		//ボタンIDを比較
		switch(sender){
		case "chat1":
			{
				//AnchorPaneは位置を座標で指定するレイアウト
				AnchorPane anchor = sendChatPane(send1);
				//AnchorPaneがnullでないなら
				if(anchor != null){
					//AnchorPaneをBorderLayoutの左側に置く
					pane.setLeft(anchor);
				}
				break;
			}
		case "chat2":
			{
				//AnchorPaneは位置を座標で指定するレイアウト
				AnchorPane anchor = sendChatPane(send2);
				//AnchorPaneがnullでないなら
				if(anchor != null){
					//AnchorPaneをBorderLayoutの右側に置く
					pane.setRight(anchor);
				}
				break;
			}
		}
		//BorderPaneをVBoxに追加
		message_display.getChildren().add(pane);
	}
	
	private AnchorPane sendChatPane(TextField message){
		//チャットテキストが空でないなら
		if(!message.getText().equals("")){
			//AnchorPaneを作る
			AnchorPane anchor = new AnchorPane();
			//チャットテキストを表示させるLabelを作る
			Label label = new Label(message.getText());
			//AnchorPaneにLabelを追加
			anchor.getChildren().add(label);
			//AnchorPaneの左上の座標から見て、CHAT_SPACE分だけ下にLabelをずらす
			label.setLayoutY(CHAT_SPACE);
			//LabelにIDを設定して、application.css内のcssを適用させる
			label.setId("chat");
			//チャット入力欄の文字を消す
			message.setText("");
			return anchor;
		}else{
			return null;
		}
	}
}
